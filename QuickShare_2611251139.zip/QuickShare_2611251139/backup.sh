#!/usr/bin/env bash
set -euo pipefail
# Run on the host. The database is stored in Docker's named volume;
# use the app's SQLite backup endpoint/script inside the container instead.
# This script backs up the database by asking the running container to do so.
BACKUP_DIR="$(cd "$(dirname "$0")" && pwd)/backups"
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
docker exec sportagent python -c \
'import sqlite3; src=sqlite3.connect("/app/data/sportagent.db"); dst=sqlite3.connect("/app/backups/sportagent_'"$STAMP"'.db"); src.backup(dst); dst.close(); src.close()'
# Copy the generated backup from the mounted backups directory and prune old copies.
find "$BACKUP_DIR" -type f -name '*.db' -mtime +14 -delete
echo "Backup completed: sportagent_${STAMP}.db"
