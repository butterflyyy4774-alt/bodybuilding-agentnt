# پروژه AI Fitness Agent

## محتویات
- Flask و SQLite
- ثبت‌نام و ورود، داشبورد، پنل مدیریت و فرم تماس
- ایمیل SMTP اختیاری
- Docker Compose، تنظیم نمونه Nginx و اسکریپت بکاپ
- SEO پایه، robots.txt، sitemap.xml و favicon

## اجرای محلی
```bash
python -m venv venv
# Windows: venv\\Scripts\\activate
# Linux/macOS: source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# در ویندوز می‌توان فایل را دستی کپی کرد.
python app.py
```
سپس به `http://127.0.0.1:5000` برو.

## اجرای Docker
```bash
cp .env.example .env
# SECRET_KEY و ADMIN_PASSWORD را حتماً تغییر بده.
docker compose up -d --build
docker compose logs -f web
```

## بکاپ روزانه روی سرور
```bash
chmod +x backup.sh
crontab -e
```
این خط را اضافه کن:
```cron
0 3 * * * /var/www/sport-agent/backup.sh >> /var/log/sportagent-backup.log 2>&1
```

## Nginx و SSL
فایل `nginx.conf` نمونه است؛ مسیر گواهی و دامنه را با سرور خودت هماهنگ کن. ابتدا DNS دامنه را به IP سرور وصل کن، سپس گواهی SSL را با Certbot بگیر و Nginx را reload کن.

## نکات مهم پیش از انتشار
1. مقادیر `SECRET_KEY`، `ADMIN_PASSWORD` و اطلاعات SMTP را در `.env` واقعی تنظیم کن؛ فایل `.env` را منتشر نکن.
2. رمز پیش‌فرض مدیر را حتماً تغییر بده.
3. دامنه `aifitness-agent.ir` در تنظیمات نمونه است؛ اگر دامنه دیگری داری، `DOMAIN` و `server_name` را اصلاح کن.
4. فرم تماس بدون SMTP پیام را در دیتابیس ذخیره می‌کند، اما ایمیل نمی‌فرستد.
5. پیشنهادهای ورزشی این نسخه عمومی‌اند و تشخیص پزشکی یا برنامه درمانی نیستند. برای کاربران زیر ۱۸ سال، محاسبه کالری و پیشنهاد کاهش وزن عمداً حذف شده است.
6. پروژه قبل از انتشار واقعی باید روی سرور مقصد تست شود و برای استفاده عمومی بهتر است محدودسازی درخواست‌ها، CSRF و پایش خطا نیز اضافه شوند.
