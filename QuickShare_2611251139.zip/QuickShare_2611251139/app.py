import os, json, sqlite3, secrets, smtplib
from datetime import timedelta
from functools import wraps
from email.mime.text import MIMEText
from flask import Flask, render_template, request, jsonify, session, redirect, Response
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
DB = os.environ.get("DATABASE_PATH", "/app/data/sportagent.db")
DOMAIN = os.environ.get("DOMAIN", "localhost:5000").strip()
IS_PRODUCTION = os.environ.get("FLASK_ENV") == "production"

if IS_PRODUCTION:
    app.config.update(SESSION_COOKIE_SECURE=True, SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Lax",
                      PERMANENT_SESSION_LIFETIME=timedelta(days=7))

def get_db():
    os.makedirs(os.path.dirname(DB) or ".", exist_ok=True)
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT UNIQUE,
        password TEXT, role TEXT DEFAULT 'athlete', age INTEGER,
        activity TEXT, goal TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS programs (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
        title TEXT, workout TEXT, rest TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS checkins (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
        sessions INTEGER, sleep INTEGER, energy INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS clubs (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, city TEXT, sports TEXT, rating REAL)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, club_id INTEGER,
        status TEXT DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, message TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    if cur.execute("SELECT COUNT(*) FROM clubs").fetchone()[0] == 0:
        cur.executemany("INSERT INTO clubs(name,city,sports,rating) VALUES(?,?,?,?)", [
            ("باشگاه پرسپولیس","تهران","فوتبال",4.8),("باشگاه استقلال","تهران","فوتبال",4.7),
            ("باشگاه فولاد","اهواز","فوتبال",4.5),("باشگاه ذوب آهن","اصفهان","فوتبال,بسکتبال",4.4),
            ("باشگاه مهرام","تهران","بسکتبال",4.6),("باشگاه پیکان","تهران","والیبال,بسکتبال",4.3),
            ("باشگاه سپاهان","اصفهان","فوتبال,والیبال",4.9)])
    admin_email = os.environ.get("ADMIN_EMAIL", "admin@sportagent.ir").lower()
    admin_password = os.environ.get("ADMIN_PASSWORD", "change-this-admin-password")
    if not cur.execute("SELECT id FROM users WHERE role='admin'").fetchone():
        cur.execute("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
                    ("مدیر", admin_email, generate_password_hash(admin_password), "admin"))
    conn.commit()
    conn.close()

@app.after_request
def security_headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "SAMEORIGIN"
    resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    if IS_PRODUCTION:
        resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return resp

@app.before_request
def force_https():
    if IS_PRODUCTION and not request.is_secure and request.headers.get("X-Forwarded-Proto") != "https":
        return redirect(request.url.replace("http://", "https://", 1), code=301)

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect("/login")
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            return jsonify({"error":"forbidden"}), 403
        return fn(*args, **kwargs)
    return wrapper

@app.route("/health")
def health():
    return {"status":"ok"}

@app.route("/")
def home(): return render_template("index.html", domain=DOMAIN)
@app.route("/login")
def login_page(): return render_template("login.html")
@app.route("/dashboard")
@login_required
def dashboard(): return render_template("dashboard.html")
@app.route("/admin")
@login_required
def admin(): return render_template("admin.html") if session.get("role") == "admin" else redirect("/dashboard")
@app.route("/contact")
def contact_page(): return render_template("contact.html", domain=DOMAIN)

@app.route("/robots.txt")
def robots():
    return Response(f"User-agent: *\nAllow: /\nSitemap: https://{DOMAIN}/sitemap.xml\n", mimetype="text/plain")
@app.route("/sitemap.xml")
def sitemap():
    urls = ["/", "/login", "/contact"]
    body = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
    body += "".join(f"<url><loc>https://{DOMAIN}{p}</loc></url>" for p in urls)
    return Response(body + "</urlset>", mimetype="application/xml")

@app.post("/api/signup")
def signup():
    d=request.get_json(silent=True) or {}
    name=str(d.get("name","")).strip(); email=str(d.get("email","")).strip().lower(); password=str(d.get("password",""))
    if not name: return jsonify(success=False,field="name",message="نام را وارد کن"),400
    if "@" not in email or "." not in email.rsplit("@",1)[-1]: return jsonify(success=False,field="email",message="ایمیل معتبر نیست"),400
    if len(password)<8: return jsonify(success=False,field="password",message="رمز باید حداقل ۸ کاراکتر باشد"),400
    conn=get_db()
    try:
        cur=conn.execute("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",(name,email,generate_password_hash(password),"athlete"))
        conn.commit(); session["user_id"]=cur.lastrowid; session["role"]="athlete"; session.permanent=True
        return jsonify(success=True,redirect="/dashboard")
    except sqlite3.IntegrityError:
        return jsonify(success=False,field="email",message="این ایمیل قبلاً ثبت شده"),400
    finally: conn.close()

@app.post("/api/login")
def login():
    d=request.get_json(silent=True) or {}; conn=get_db()
    u=conn.execute("SELECT * FROM users WHERE email=?",(str(d.get("email","")).strip().lower(),)).fetchone(); conn.close()
    if not u or not check_password_hash(u["password"],str(d.get("password",""))):
        return jsonify(success=False,message="ایمیل یا رمز عبور نادرست است"),401
    session.clear(); session["user_id"]=u["id"]; session["role"]=u["role"]; session.permanent=True
    return jsonify(success=True,redirect="/admin" if u["role"]=="admin" else "/dashboard")

@app.route("/logout")
def logout(): session.clear(); return redirect("/")

@app.get("/api/me")
@login_required
def me():
    conn=get_db(); u=conn.execute("SELECT name,email,role,age,activity,goal FROM users WHERE id=?",(session["user_id"],)).fetchone(); conn.close()
    return jsonify(dict(u) if u else {})

@app.post("/api/onboarding")
@login_required
def onboarding():
    d=request.get_json(silent=True) or {}
    try: age=int(d.get("age"))
    except (ValueError,TypeError): return jsonify(success=False,message="سن معتبر وارد کن"),400
    if not 13<=age<=90: return jsonify(success=False,field="age",message="سن باید بین ۱۳ تا ۹۰ باشد"),400
    activity=d.get("activity","medium")
    if activity not in ("low","medium","high"): activity="medium"
    goal=d.get("goal","fitness")
    plans={
      "fitness":("پیاده‌روی، بازی یا فعالیت دلخواه با شدت متعادل","استراحت کافی و توجه به نشانه‌های خستگی"),
      "mobility":("حرکات کششی ملایم و تمرین تعادل بدون درد","حرکات آرام و روزهای ریکاوری"),
      "endurance":("افزایش تدریجی زمان فعالیت هوازی متناسب با توان","استراحت بین جلسات و خواب کافی"),
      "strength":("تمرین مقاومتی سبک با آموزش صحیح حرکت و نظارت مناسب","فاصله کافی بین جلسات و پرهیز از تمرین با درد")
    }
    workout,rest=plans.get(goal,plans["fitness"])
    # برای افراد زیر ۱۸ سال هیچ هدف کالری، رژیم کاهش وزن یا پیگیری وزن تولید نمی‌شود.
    title="پیشنهاد فعالیت متعادل"
    if age < 18:
        rest += "؛ در سن رشد از رژیم محدودکننده یا تمرین سنگین بدون راهنمایی متخصص پرهیز کن."
    conn=get_db()
    conn.execute("UPDATE users SET age=?,activity=?,goal=? WHERE id=?",(age,activity,goal,session["user_id"]))
    conn.execute("INSERT INTO programs(user_id,title,workout,rest) VALUES(?,?,?,?)",(session["user_id"],title,workout,rest))
    conn.commit(); conn.close()
    return jsonify(success=True,message="پیشنهاد فعالیتت آماده شد.",program={"title":title,"workout":workout,"rest":rest})

@app.post("/api/checkin")
@login_required
def checkin():
    d=request.get_json(silent=True) or {}
    try: sessions=int(d.get("sessions",0)); sleep=int(d.get("sleep",3)); energy=int(d.get("energy",3))
    except (ValueError,TypeError): return jsonify(success=False,message="اطلاعات معتبر نیست"),400
    if not 0<=sessions<=7 or not 1<=sleep<=5 or not 1<=energy<=5:
        return jsonify(success=False,message="مقادیر واردشده خارج از محدوده‌اند"),400
    conn=get_db(); conn.execute("INSERT INTO checkins(user_id,sessions,sleep,energy) VALUES(?,?,?,?)",(session["user_id"],sessions,sleep,energy)); conn.commit(); conn.close()
    return jsonify(success=True,message="ثبت شد.")

@app.get("/api/my-programs")
@login_required
def my_programs():
    conn=get_db(); rows=conn.execute("SELECT * FROM programs WHERE user_id=? ORDER BY id DESC",(session["user_id"],)).fetchall(); conn.close()
    return jsonify(programs=[dict(r) for r in rows])

@app.get("/api/clubs")
def clubs():
    conn=get_db(); rows=conn.execute("SELECT * FROM clubs").fetchall(); conn.close()
    return jsonify(clubs=[{"id":r["id"],"name":r["name"],"city":r["city"],"sports":r["sports"].split(","),"rating":r["rating"]} for r in rows])

@app.post("/api/request-club/<int:cid>")
@login_required
def request_club(cid):
    conn=get_db()
    if not conn.execute("SELECT id FROM clubs WHERE id=?",(cid,)).fetchone(): conn.close(); return jsonify(success=False,message="باشگاه پیدا نشد"),404
    conn.execute("INSERT INTO requests(user_id,club_id) VALUES(?,?)",(session["user_id"],cid)); conn.commit(); conn.close()
    return jsonify(success=True,message="درخواست ثبت شد.")

@app.post("/api/contact")
def contact_submit():
    d=request.get_json(silent=True) or {}
    name=str(d.get("name","")).strip(); email=str(d.get("email","")).strip(); message=str(d.get("message","")).strip()
    if not name or not email or not message: return jsonify(success=False,message="همه فیلدها الزامی است"),400
    if "@" not in email: return jsonify(success=False,field="email",message="ایمیل معتبر نیست"),400
    if len(message)>10000: return jsonify(success=False,message="پیام بیش از حد طولانی است"),400
    conn=get_db(); conn.execute("INSERT INTO messages(name,email,message) VALUES(?,?,?)",(name,email,message)); conn.commit(); conn.close()
    try:
        host=os.getenv("SMTP_HOST"); user=os.getenv("SMTP_USER"); password=os.getenv("SMTP_PASS"); target=os.getenv("CONTACT_EMAIL",user)
        if host and user and password and target:
            msg=MIMEText(f"نام: {name}\nایمیل: {email}\n\nپیام:\n{message}","plain","utf-8")
            msg["Subject"]="پیام جدید از سایت AI Fitness Agent"; msg["From"]=user; msg["To"]=target
            with smtplib.SMTP(host,int(os.getenv("SMTP_PORT","587")),timeout=15) as smtp:
                smtp.starttls(); smtp.login(user,password); smtp.send_message(msg)
    except Exception as exc: app.logger.warning("SMTP delivery failed: %s",exc)
    return jsonify(success=True,message="پیامت ثبت شد. ممنون!")

@app.get("/api/admin/stats")
@login_required
@admin_required
def admin_stats():
    conn=get_db()
    stats={"users":conn.execute("SELECT COUNT(*) FROM users WHERE role='athlete'").fetchone()[0],
           "programs":conn.execute("SELECT COUNT(*) FROM programs").fetchone()[0],
           "requests":conn.execute("SELECT COUNT(*) FROM requests").fetchone()[0],
           "clubs":conn.execute("SELECT COUNT(*) FROM clubs").fetchone()[0]}
    conn.close(); return jsonify(stats)

@app.get("/api/admin/athletes")
@login_required
@admin_required
def admin_athletes():
    conn=get_db(); rows=conn.execute("SELECT id,name,email,age,goal,created_at FROM users WHERE role='athlete' ORDER BY id DESC").fetchall(); conn.close()
    return jsonify(athletes=[dict(r) for r in rows])

@app.get("/api/admin/messages")
@login_required
@admin_required
def admin_messages():
    conn=get_db(); rows=conn.execute("SELECT * FROM messages ORDER BY id DESC LIMIT 50").fetchall(); conn.close()
    return jsonify(messages=[dict(r) for r in rows])

@app.get("/api/admin/requests")
@login_required
@admin_required
def admin_requests():
    conn=get_db(); rows=conn.execute("""SELECT r.id,u.name athlete,c.name club,r.status,r.created_at
        FROM requests r LEFT JOIN users u ON r.user_id=u.id LEFT JOIN clubs c ON r.club_id=c.id ORDER BY r.id DESC""").fetchall(); conn.close()
    return jsonify(requests=[dict(r) for r in rows])

@app.delete("/api/admin/athlete/<int:uid>")
@login_required
@admin_required
def delete_athlete(uid):
    conn=get_db()
    conn.execute("DELETE FROM programs WHERE user_id=?",(uid,)); conn.execute("DELETE FROM checkins WHERE user_id=?",(uid,))
    conn.execute("DELETE FROM requests WHERE user_id=?",(uid,)); conn.execute("DELETE FROM users WHERE id=? AND role='athlete'",(uid,))
    conn.commit(); conn.close(); return jsonify(success=True,message="کاربر حذف شد")

if __name__=="__main__":
    init_db()
    if IS_PRODUCTION:
        from waitress import serve
        serve(app,host="0.0.0.0",port=5000,threads=4)
    else:
        app.run(debug=True,host="127.0.0.1",port=5000)
